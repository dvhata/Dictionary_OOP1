package sample;

import java.util.Vector;

public class Dictionary {
    public static Vector<Word> words = new Vector<>();

//    public Dictionary() {
//        words = new Vector<Word>();
//    }

}


